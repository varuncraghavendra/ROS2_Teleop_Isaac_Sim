import rclpy
from rclpy.node import Node

from px4_msgs.msg import OffboardControlMode, TrajectorySetpoint, VehicleCommand

class OffboardNode(Node):
    def __init__(self):
        super().__init__('offboard_node')

        self.offboard_pub = self.create_publisher(OffboardControlMode, '/fmu/in/offboard_control_mode', 10)
        self.traj_pub = self.create_publisher(TrajectorySetpoint, '/fmu/in/trajectory_setpoint', 10)
        self.cmd_pub = self.create_publisher(VehicleCommand, '/fmu/in/vehicle_command', 10)

        self.timer = self.create_timer(0.1, self.tick)  # 10 Hz
        self.counter = 0

    def tick(self):
        now_us = int(self.get_clock().now().nanoseconds / 1000)

        # 1) Offboard mode heartbeat
        o = OffboardControlMode()
        o.timestamp = now_us
        o.position = True
        o.velocity = False
        o.acceleration = False
        o.attitude = False
        o.body_rate = False
        self.offboard_pub.publish(o)

        # 2) Send a position setpoint
        sp = TrajectorySetpoint()
        sp.timestamp = now_us
        sp.position = [0.0, 0.0, -2.0]  # NED: -z is up
        sp.yaw = 0.0
        self.traj_pub.publish(sp)

        # 3) After a short warmup, arm + switch to offboard
        if self.counter == 20:
            self.send_vehicle_command(176, 1.0)  # VEHICLE_CMD_DO_SET_MODE (custom mode mapping varies)
            self.send_vehicle_command(400, 1.0)  # VEHICLE_CMD_COMPONENT_ARM_DISARM arm=1
        self.counter += 1

    def send_vehicle_command(self, command: int, param1: float):
        now_us = int(self.get_clock().now().nanoseconds / 1000)

        cmd = VehicleCommand()
        cmd.timestamp = now_us
        cmd.param1 = float(param1)
        cmd.command = int(command)
        cmd.target_system = 1
        cmd.target_component = 1
        cmd.source_system = 1
        cmd.source_component = 1
        cmd.from_external = True
        self.cmd_pub.publish(cmd)

def main():
    rclpy.init()
    node = OffboardNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

