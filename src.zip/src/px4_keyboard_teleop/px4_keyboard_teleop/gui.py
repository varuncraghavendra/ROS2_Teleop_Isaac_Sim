#!/usr/bin/env python3
import sys
import math
from dataclasses import dataclass

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from px4_msgs.msg import OffboardControlMode, TrajectorySetpoint, VehicleCommand
from px4_msgs.msg import VehicleLocalPosition, VehicleOdometry, VehicleAttitude, VehicleStatus

from PyQt5 import QtCore, QtWidgets


@dataclass
class Setpoint:
    x: float = 0.0   # local NED
    y: float = 0.0
    z: float = 0.0   # down (up is negative)
    yaw: float = 0.0 # rad


def quat_to_yaw(qw, qx, qy, qz) -> float:
    siny_cosp = 2.0 * (qw * qz + qx * qy)
    cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
    return math.atan2(siny_cosp, cosy_cosp)


class PX4OffboardPositionController(Node):
    """
    Core controller:
      - OFFBOARD position setpoints at 20 Hz
      - Body-relative translation (forward/right) converted using yaw_est
      - Buttons for arm/offboard/takeoff/land/hold
      - Exposes methods the GUI can call
    """

    VEHICLE_CMD_DO_SET_MODE = 176
    VEHICLE_CMD_COMPONENT_ARM_DISARM = 400
    VEHICLE_CMD_NAV_LAND = 21
    PX4_CUSTOM_MAIN_MODE = 1.0
    PX4_OFFBOARD_MODE = 6.0

    def __init__(self):
        super().__init__("px4_offboard_gui_controller")

        self.pub_offboard = self.create_publisher(
            OffboardControlMode, "/fmu/in/offboard_control_mode", qos_profile_sensor_data
        )
        self.pub_sp = self.create_publisher(
            TrajectorySetpoint, "/fmu/in/trajectory_setpoint", qos_profile_sensor_data
        )
        self.pub_cmd = self.create_publisher(
            VehicleCommand, "/fmu/in/vehicle_command", qos_profile_sensor_data
        )

        # Pose sources
        self.sub_local = self.create_subscription(
            VehicleLocalPosition, "/fmu/out/vehicle_local_position", self._on_local, qos_profile_sensor_data
        )
        self.sub_odom = self.create_subscription(
            VehicleOdometry, "/fmu/out/vehicle_odometry", self._on_odom, qos_profile_sensor_data
        )
        self.sub_att = self.create_subscription(
            VehicleAttitude, "/fmu/out/vehicle_attitude", self._on_att, qos_profile_sensor_data
        )
        self.sub_status = self.create_subscription(
            VehicleStatus, "/fmu/out/vehicle_status", self._on_status, qos_profile_sensor_data
        )

        self.timer = self.create_timer(0.05, self._tick)  # 20 Hz
        self.stream_count = 0

        # Estimator state
        self.have_pose = False
        self.pose_source = "none"
        self.x = self.y = self.z = 0.0

        self.have_yaw = False
        self.yaw_est = 0.0
        self.yaw_source = "none"

        self.have_status = False
        self.arming_state = None
        self.nav_state = None

        # Commanded setpoint
        self.sp = Setpoint()

        # Tunables (GUI changes these)
        self.step_xy = 0.5
        self.step_z = 0.3
        self.step_yaw = math.radians(10)
        self.takeoff_alt_m = 2.5
        self.alt_ceiling_m = 30.0
        self.alt_floor_m = 0.1

        # Command request flags (don’t spam)
        self._arm_requested = False
        self._offboard_requested = False

        # Takeoff mode
        self.takeoff_active = False

    def now_us(self) -> int:
        return int(self.get_clock().now().nanoseconds / 1000)

    # ---------- subscriptions ----------
    def _on_local(self, msg: VehicleLocalPosition):
        self.x, self.y, self.z = float(msg.x), float(msg.y), float(msg.z)
        self.have_pose = True
        self.pose_source = "vehicle_local_position"

    def _on_odom(self, msg: VehicleOdometry):
        if self.pose_source != "vehicle_local_position":
            self.x, self.y, self.z = float(msg.position[0]), float(msg.position[1]), float(msg.position[2])
            self.have_pose = True
            self.pose_source = "vehicle_odometry"

        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.yaw_est = quat_to_yaw(qw, qx, qy, qz)
        self.have_yaw = True
        self.yaw_source = "vehicle_odometry"

    def _on_att(self, msg: VehicleAttitude):
        if self.yaw_source == "vehicle_odometry":
            return
        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.yaw_est = quat_to_yaw(qw, qx, qy, qz)
        self.have_yaw = True
        self.yaw_source = "vehicle_attitude"

    def _on_status(self, msg: VehicleStatus):
        self.have_status = True
        self.arming_state = int(msg.arming_state)
        self.nav_state = int(msg.nav_state)

    # ---------- command helpers ----------
    def _send_cmd(self, command: int, p1: float = 0.0, p2: float = 0.0):
        m = VehicleCommand()
        m.timestamp = self.now_us()
        m.param1 = float(p1)
        m.param2 = float(p2)
        m.command = int(command)
        m.target_system = 1
        m.target_component = 1
        m.source_system = 1
        m.source_component = 1
        m.from_external = True
        self.pub_cmd.publish(m)

    def request_arm(self):
        if not self._arm_requested:
            self._send_cmd(self.VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0, 0.0)
            self._arm_requested = True

    def request_offboard(self):
        if not self._offboard_requested:
            self._send_cmd(self.VEHICLE_CMD_DO_SET_MODE, self.PX4_CUSTOM_MAIN_MODE, self.PX4_OFFBOARD_MODE)
            self._offboard_requested = True

    def land(self):
        self.takeoff_active = False
        self._send_cmd(self.VEHICLE_CMD_NAV_LAND, 0.0, 0.0)

    def hold(self):
        """Hold at current position (best effort)."""
        if self.have_pose:
            self.sp.x, self.sp.y, self.sp.z = self.x, self.y, self.z
        self.takeoff_active = False

    def init_setpoint_to_current(self):
        if not self.have_pose:
            return False
        self.sp.x, self.sp.y, self.sp.z = self.x, self.y, self.z
        if self.have_yaw:
            self.sp.yaw = self.yaw_est
        self.takeoff_active = False
        return True

    def start_takeoff(self):
        if not self.have_pose:
            return False
        self.sp.x, self.sp.y = self.x, self.y
        self.sp.z = -self.takeoff_alt_m
        if self.have_yaw:
            self.sp.yaw = self.yaw_est
        self.takeoff_active = True
        return True

    # ---------- motion in body frame ----------
    def _body_to_local_dxdy(self, forward_m: float, right_m: float):
        yaw = self.yaw_est if self.have_yaw else 0.0
        cy = math.cos(yaw)
        sy = math.sin(yaw)
        dx = forward_m * cy - right_m * sy
        dy = forward_m * sy + right_m * cy
        return dx, dy

    def step_body(self, forward: float, right: float):
        """Move setpoint by (forward,right) meters in body frame."""
        self.takeoff_active = False
        dx, dy = self._body_to_local_dxdy(forward, right)
        self.sp.x += dx
        self.sp.y += dy

    def step_up(self, up_m: float):
        """Up in meters (positive means go up)."""
        self.takeoff_active = False
        self.sp.z -= up_m  # up => more negative z

    def step_yaw_deg(self, deg: float):
        """Yaw setpoint increment in degrees (positive left)."""
        self.takeoff_active = False
        self.sp.yaw += math.radians(deg)
        self.sp.yaw = (self.sp.yaw + math.pi) % (2.0 * math.pi) - math.pi

    def _clamp_alt(self):
        target_alt = -self.sp.z
        if target_alt > self.alt_ceiling_m:
            self.sp.z = -self.alt_ceiling_m
        if target_alt < self.alt_floor_m:
            self.sp.z = -self.alt_floor_m

    # ---------- 20 Hz stream ----------
    def _tick(self):
        self.stream_count += 1

        hb = OffboardControlMode()
        hb.timestamp = self.now_us()
        hb.position = True
        hb.velocity = False
        hb.acceleration = False
        hb.attitude = False
        hb.body_rate = False
        self.pub_offboard.publish(hb)

        # During takeoff: after ~1s setpoint stream, request arm+offboard once
        if self.takeoff_active and self.stream_count > 20:
            self.request_arm()
            self.request_offboard()

        self._clamp_alt()
        sp = TrajectorySetpoint()
        sp.timestamp = self.now_us()
        sp.position = [float(self.sp.x), float(self.sp.y), float(self.sp.z)]
        sp.yaw = float(self.sp.yaw)
        self.pub_sp.publish(sp)

    # ---------- telemetry snapshot for GUI ----------
    def telemetry(self):
        alt = (-self.z) if self.have_pose else None
        yaw_deg = math.degrees(self.yaw_est) if self.have_yaw else None
        return {
            "have_pose": self.have_pose,
            "pose_source": self.pose_source,
            "x": self.x, "y": self.y, "z": self.z,
            "alt": alt,
            "have_yaw": self.have_yaw,
            "yaw_deg": yaw_deg,
            "yaw_source": self.yaw_source,
            "arming_state": self.arming_state,
            "nav_state": self.nav_state,
            "sp_x": self.sp.x, "sp_y": self.sp.y, "sp_z": self.sp.z,
            "sp_alt": -self.sp.z,
            "sp_yaw_deg": math.degrees(self.sp.yaw),
        }


class GUI(QtWidgets.QWidget):
    def __init__(self, ctrl: PX4OffboardPositionController):
        super().__init__()
        self.ctrl = ctrl
        self.setWindowTitle("PX4 Offboard GUI (Isaac + DDS)")

        # --- Buttons ---
        self.btn_init = QtWidgets.QPushButton("Init SP = Current")
        self.btn_arm = QtWidgets.QPushButton("ARM (once)")
        self.btn_offboard = QtWidgets.QPushButton("OFFBOARD (once)")
        self.btn_takeoff = QtWidgets.QPushButton("TAKEOFF")
        self.btn_hold = QtWidgets.QPushButton("HOLD")
        self.btn_land = QtWidgets.QPushButton("LAND")

        # --- Sliders / controls ---
        self.step_xy = QtWidgets.QDoubleSpinBox()
        self.step_xy.setRange(0.1, 5.0)
        self.step_xy.setSingleStep(0.1)
        self.step_xy.setValue(self.ctrl.step_xy)

        self.step_z = QtWidgets.QDoubleSpinBox()
        self.step_z.setRange(0.05, 3.0)
        self.step_z.setSingleStep(0.05)
        self.step_z.setValue(self.ctrl.step_z)

        self.takeoff_alt = QtWidgets.QDoubleSpinBox()
        self.takeoff_alt.setRange(0.5, 50.0)
        self.takeoff_alt.setSingleStep(0.5)
        self.takeoff_alt.setValue(self.ctrl.takeoff_alt_m)

        # --- Telemetry label ---
        self.lbl = QtWidgets.QLabel("Telemetry...")

        # Layout
        grid = QtWidgets.QGridLayout()
        self.setLayout(grid)

        grid.addWidget(self.btn_init, 0, 0, 1, 2)
        grid.addWidget(self.btn_arm, 1, 0)
        grid.addWidget(self.btn_offboard, 1, 1)
        grid.addWidget(self.btn_takeoff, 2, 0)
        grid.addWidget(self.btn_hold, 2, 1)
        grid.addWidget(self.btn_land, 3, 0, 1, 2)

        grid.addWidget(QtWidgets.QLabel("Step XY (m)"), 4, 0)
        grid.addWidget(self.step_xy, 4, 1)
        grid.addWidget(QtWidgets.QLabel("Step Z (m)"), 5, 0)
        grid.addWidget(self.step_z, 5, 1)
        grid.addWidget(QtWidgets.QLabel("Takeoff Alt (m)"), 6, 0)
        grid.addWidget(self.takeoff_alt, 6, 1)

        grid.addWidget(QtWidgets.QLabel("Keyboard (focus this window):"), 7, 0, 1, 2)
        grid.addWidget(QtWidgets.QLabel("W/A/S/D = body move, R/F = up/down, Q/E = yaw"), 8, 0, 1, 2)
        grid.addWidget(self.lbl, 9, 0, 1, 2)

        # Wire button actions
        self.btn_init.clicked.connect(self.on_init)
        self.btn_arm.clicked.connect(self.on_arm)
        self.btn_offboard.clicked.connect(self.on_offboard)
        self.btn_takeoff.clicked.connect(self.on_takeoff)
        self.btn_hold.clicked.connect(self.on_hold)
        self.btn_land.clicked.connect(self.on_land)

        # Wire value updates
        self.step_xy.valueChanged.connect(self.on_params_changed)
        self.step_z.valueChanged.connect(self.on_params_changed)
        self.takeoff_alt.valueChanged.connect(self.on_params_changed)

        # UI refresh timer (10 Hz)
        self.ui_timer = QtCore.QTimer()
        self.ui_timer.timeout.connect(self.refresh)
        self.ui_timer.start(100)

        self.setFocusPolicy(QtCore.Qt.StrongFocus)
        self.resize(520, 360)

    def on_params_changed(self):
        self.ctrl.step_xy = float(self.step_xy.value())
        self.ctrl.step_z = float(self.step_z.value())
        self.ctrl.takeoff_alt_m = float(self.takeoff_alt.value())

    def on_init(self):
        ok = self.ctrl.init_setpoint_to_current()
        if not ok:
            QtWidgets.QMessageBox.warning(self, "No pose", "No estimator pose yet (/fmu/out/*).")

    def on_arm(self):
        self.ctrl.request_arm()

    def on_offboard(self):
        if not self.ctrl.have_pose:
            QtWidgets.QMessageBox.warning(self, "No pose", "No estimator pose yet (/fmu/out/*).")
            return
        self.ctrl.request_offboard()

    def on_takeoff(self):
        ok = self.ctrl.start_takeoff()
        if not ok:
            QtWidgets.QMessageBox.warning(self, "No pose", "No estimator pose yet (/fmu/out/*).")

    def on_hold(self):
        self.ctrl.hold()

    def on_land(self):
        self.ctrl.land()

    # Keyboard in the GUI window
    def keyPressEvent(self, e):
        k = e.key()
        sxy = self.ctrl.step_xy
        sz = self.ctrl.step_z

        if k == QtCore.Qt.Key_W:
            self.ctrl.step_body(+sxy, 0.0)
        elif k == QtCore.Qt.Key_S:
            self.ctrl.step_body(-sxy, 0.0)
        elif k == QtCore.Qt.Key_D:
            self.ctrl.step_body(0.0, +sxy)
        elif k == QtCore.Qt.Key_A:
            self.ctrl.step_body(0.0, -sxy)
        elif k == QtCore.Qt.Key_R:
            self.ctrl.step_up(+sz)
        elif k == QtCore.Qt.Key_F:
            self.ctrl.step_up(-sz)  # down
        elif k == QtCore.Qt.Key_Q:
            self.ctrl.step_yaw_deg(+10.0)
        elif k == QtCore.Qt.Key_E:
            self.ctrl.step_yaw_deg(-10.0)
        elif k == QtCore.Qt.Key_Space:
            self.ctrl.request_arm()
        elif k == QtCore.Qt.Key_O:
            self.ctrl.request_offboard()
        elif k == QtCore.Qt.Key_T:
            self.ctrl.start_takeoff()
        elif k == QtCore.Qt.Key_H:
            self.ctrl.hold()
        elif k == QtCore.Qt.Key_L:
            self.ctrl.land()

    def refresh(self):
        t = self.ctrl.telemetry()
        self.lbl.setText(
            f"Pose: {t['have_pose']} ({t['pose_source']})  "
            f"Alt: {('%.2f' % t['alt']) if t['alt'] is not None else '---'} m\n"
            f"Yaw: {t['yaw_deg'] if t['yaw_deg'] is not None else '---'} deg ({t['yaw_source']})\n"
            f"SP: x={t['sp_x']:.2f} y={t['sp_y']:.2f} z={t['sp_z']:.2f} (alt={t['sp_alt']:.2f}) yaw_sp={t['sp_yaw_deg']:.1f}°"
        )


def main():
    rclpy.init()

    ctrl = PX4OffboardPositionController()

    app = QtWidgets.QApplication(sys.argv)
    gui = GUI(ctrl)
    gui.show()

    # Spin ROS in a Qt timer (keeps GUI responsive)
    spin_timer = QtCore.QTimer()
    spin_timer.timeout.connect(lambda: rclpy.spin_once(ctrl, timeout_sec=0.0))
    spin_timer.start(10)  # 100 Hz spin

    rc = app.exec_()

    ctrl.destroy_node()
    rclpy.shutdown()
    sys.exit(rc)


if __name__ == "__main__":
    main()

