#!/usr/bin/env python3
import sys
import math
import select
import termios
import tty
from dataclasses import dataclass

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from px4_msgs.msg import OffboardControlMode, TrajectorySetpoint, VehicleCommand
from px4_msgs.msg import VehicleLocalPosition, VehicleOdometry, VehicleStatus
from px4_msgs.msg import VehicleAttitude


def get_key(timeout=0.0):
    rlist, _, _ = select.select([sys.stdin], [], [], timeout)
    if rlist:
        return sys.stdin.read(1)
    return None


@dataclass
class Setpoint:
    x: float = 0.0   # local NED
    y: float = 0.0
    z: float = 0.0   # down (up is negative)
    yaw: float = 0.0 # rad


def quat_to_yaw_ned(qw: float, qx: float, qy: float, qz: float) -> float:
    """
    Quaternion -> yaw (heading) in radians.
    Assumes quaternion is in the same convention PX4 publishes in VehicleOdometry/VehicleAttitude.
    This standard formula returns yaw about Z axis.
    """
    # yaw (z-axis rotation)
    siny_cosp = 2.0 * (qw * qz + qx * qy)
    cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
    return math.atan2(siny_cosp, cosy_cosp)


class PX4KeyboardOffboardPositionBody(Node):
    """
    OFFBOARD POSITION keyboard teleop, but translations are BODY-relative:

      - W/S: forward/back along drone nose
      - A/D: left/right relative to nose

    We convert body step (forward/right) into local NED (x,y) using current yaw.

    Notes:
    - Setpoints are local frame.
    - Yaw comes from VehicleOdometry quaternion (preferred) or VehicleAttitude.
    """

    VEHICLE_CMD_DO_SET_MODE = 176
    VEHICLE_CMD_COMPONENT_ARM_DISARM = 400
    VEHICLE_CMD_NAV_LAND = 21

    PX4_CUSTOM_MAIN_MODE = 1.0
    PX4_OFFBOARD_MODE = 6.0

    def __init__(self):
        super().__init__("px4_keyboard_offboard_position_body")

        # Publishers
        self.pub_offboard = self.create_publisher(
            OffboardControlMode, "/fmu/in/offboard_control_mode", qos_profile_sensor_data
        )
        self.pub_sp = self.create_publisher(
            TrajectorySetpoint, "/fmu/in/trajectory_setpoint", qos_profile_sensor_data
        )
        self.pub_cmd = self.create_publisher(
            VehicleCommand, "/fmu/in/vehicle_command", qos_profile_sensor_data
        )

        # Subscriptions (pose + status + attitude sources)
        self.sub_local = self.create_subscription(
            VehicleLocalPosition, "/fmu/out/vehicle_local_position", self._on_local, qos_profile_sensor_data
        )
        self.sub_odom = self.create_subscription(
            VehicleOdometry, "/fmu/out/vehicle_odometry", self._on_odom, qos_profile_sensor_data
        )
        self.sub_att = self.create_subscription(
            VehicleAttitude, "/fmu/out/vehicle_attitude", self._on_att, qos_profile_sensor_data
        )
        self.sub_status = self.create_subscription(
            VehicleStatus, "/fmu/out/vehicle_status", self._on_status, qos_profile_sensor_data
        )

        # Timer for heartbeat + setpoints
        self.timer = self.create_timer(0.05, self._tick)  # 20 Hz
        self.stream_count = 0

        # Estimator pose
        self.have_pose = False
        self.pose_source = "none"
        self.x = self.y = self.z = 0.0  # current local NED

        # Yaw estimate (for body-relative motion)
        self.have_yaw = False
        self.yaw_est = 0.0
        self.yaw_source = "none"

        # Vehicle status (optional, but useful)
        self.have_status = False
        self.arming_state = None
        self.nav_state = None

        # Commanded setpoint
        self.sp = Setpoint()

        # Steps
        self.step_body_xy = 0.5   # meters per keypress in body plane
        self.step_z = 0.3         # meters per keypress
        self.step_yaw = math.radians(10)

        # Takeoff
        self.takeoff_alt_m = 2.5
        self.takeoff_active = False

        # Safety
        self.alt_ceiling_m = 30.0
        self.alt_floor_m = 0.1

        # Command request flags (to avoid spamming)
        self._arm_requested = False
        self._offboard_requested = False

        self._help()

    def _help(self):
        self.get_logger().info(
            "\n=== OFFBOARD POSITION (Body-relative WASD) ===\n"
            "W/S: forward/back along nose\n"
            "A/D: left/right relative to nose\n"
            "R/F: up/down\n"
            "Q/E: yaw left/right (changes yaw setpoint)\n"
            "\nSPACE: ARM (sent once)\n"
            "O: OFFBOARD (init SP=current, request offboard once)\n"
            "T: TAKEOFF (arm+offboard+alt)\n"
            "H: HOLD (SP=current)\n"
            "L: LAND\n"
            "+/-: change XY step\n"
            "]/[: change takeoff altitude\n"
        )

    def now_us(self) -> int:
        return int(self.get_clock().now().nanoseconds / 1000)

    # -------------------- Subscribers --------------------
    def _on_local(self, msg: VehicleLocalPosition):
        self.x, self.y, self.z = float(msg.x), float(msg.y), float(msg.z)
        self.have_pose = True
        self.pose_source = "vehicle_local_position"

    def _on_odom(self, msg: VehicleOdometry):
        # Pose fallback
        if self.pose_source != "vehicle_local_position":
            self.x, self.y, self.z = float(msg.position[0]), float(msg.position[1]), float(msg.position[2])
            self.have_pose = True
            self.pose_source = "vehicle_odometry"

        # Yaw preferred source: odometry quaternion
        # px4_msgs VehicleOdometry: q is [w,x,y,z]
        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.yaw_est = quat_to_yaw_ned(qw, qx, qy, qz)
        self.have_yaw = True
        self.yaw_source = "vehicle_odometry"

    def _on_att(self, msg: VehicleAttitude):
        # Use attitude only if odometry isn't providing yaw yet
        if self.yaw_source == "vehicle_odometry":
            return
        # px4_msgs VehicleAttitude: q is [w,x,y,z]
        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.yaw_est = quat_to_yaw_ned(qw, qx, qy, qz)
        self.have_yaw = True
        self.yaw_source = "vehicle_attitude"

    def _on_status(self, msg: VehicleStatus):
        self.have_status = True
        self.arming_state = int(msg.arming_state)
        self.nav_state = int(msg.nav_state)

    # -------------------- Commands --------------------
    def _send_cmd(self, command: int, p1: float = 0.0, p2: float = 0.0):
        m = VehicleCommand()
        m.timestamp = self.now_us()
        m.param1 = float(p1)
        m.param2 = float(p2)
        m.command = int(command)
        m.target_system = 1
        m.target_component = 1
        m.source_system = 1
        m.source_component = 1
        m.from_external = True
        self.pub_cmd.publish(m)

    def request_arm(self):
        if not self._arm_requested:
            self._send_cmd(self.VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0, 0.0)
            self._arm_requested = True
            self.get_logger().info("ARM requested (once)")

    def request_offboard(self):
        if not self._offboard_requested:
            self._send_cmd(self.VEHICLE_CMD_DO_SET_MODE, self.PX4_CUSTOM_MAIN_MODE, self.PX4_OFFBOARD_MODE)
            self._offboard_requested = True
            self.get_logger().info("OFFBOARD requested (once)")

    def land(self):
        self.takeoff_active = False
        self._send_cmd(self.VEHICLE_CMD_NAV_LAND, 0.0, 0.0)
        self.get_logger().info("LAND sent")

    # -------------------- Setpoint helpers --------------------
    def setpoint_to_current(self) -> bool:
        if not self.have_pose:
            self.get_logger().warning("No estimator pose yet; cannot init setpoint.")
            return False
        self.sp.x, self.sp.y, self.sp.z = self.x, self.y, self.z
        # initialize yaw setpoint to current yaw if available
        if self.have_yaw:
            self.sp.yaw = self.yaw_est
        self.takeoff_active = False
        self.get_logger().info(
            f"SP=current ({self.pose_source}), yaw_source={self.yaw_source}, alt={-self.sp.z:.2f}m"
        )
        return True

    def start_takeoff(self):
        if not self.have_pose:
            self.get_logger().warning("No estimator pose yet; cannot takeoff.")
            return
        # Keep current XY, go to altitude
        self.sp.x, self.sp.y = self.x, self.y
        self.sp.z = -self.takeoff_alt_m
        if self.have_yaw:
            self.sp.yaw = self.yaw_est
        self.takeoff_active = True
        self.get_logger().info(f"TAKEOFF: target alt={self.takeoff_alt_m:.1f}m (z={self.sp.z:.2f})")

    def _clamp_alt(self):
        target_alt = -self.sp.z
        if target_alt > self.alt_ceiling_m:
            self.sp.z = -self.alt_ceiling_m
        if target_alt < self.alt_floor_m:
            self.sp.z = -self.alt_floor_m

    def _body_step_to_local(self, forward_m: float, right_m: float):
        """
        Convert body-plane step (forward/right) to local NED delta (x,y) using current yaw.
        If yaw unknown, treat body == local (fallback).
        """
        yaw = self.yaw_est if self.have_yaw else 0.0
        cy = math.cos(yaw)
        sy = math.sin(yaw)

        # Body axes: forward, right
        # Local NED: x forward (north), y right (east)
        dx = forward_m * cy - right_m * sy
        dy = forward_m * sy + right_m * cy
        return dx, dy

    # -------------------- Main timer --------------------
    def _tick(self):
        self.stream_count += 1

        # 1) Offboard heartbeat (POSITION control)
        hb = OffboardControlMode()
        hb.timestamp = self.now_us()
        hb.position = True
        hb.velocity = False
        hb.acceleration = False
        hb.attitude = False
        hb.body_rate = False
        self.pub_offboard.publish(hb)

        # 2) During takeoff: after ~1s streaming, request arm + offboard (once)
        if self.takeoff_active and self.stream_count > 20:
            self.request_arm()
            self.request_offboard()

        # 3) Publish setpoint
        self._clamp_alt()
        sp = TrajectorySetpoint()
        sp.timestamp = self.now_us()
        sp.position = [float(self.sp.x), float(self.sp.y), float(self.sp.z)]
        sp.yaw = float(self.sp.yaw)
        self.pub_sp.publish(sp)

    # -------------------- Key handler --------------------
    def handle_key(self, k: str):
        # Actions
        if k == " ":
            self.request_arm()
            return
        if k in ("o", "O"):
            if self.setpoint_to_current() and self.stream_count > 10:
                self.request_offboard()
            return
        if k in ("t", "T"):
            self.start_takeoff()
            return
        if k in ("h", "H"):
            self.setpoint_to_current()
            return
        if k in ("l", "L"):
            self.land()
            return

        # Tuning
        if k == "+":
            self.step_body_xy = min(3.0, self.step_body_xy + 0.1)
            self.get_logger().info(f"step_xy={self.step_body_xy:.1f}m")
            return
        if k == "-":
            self.step_body_xy = max(0.1, self.step_body_xy - 0.1)
            self.get_logger().info(f"step_xy={self.step_body_xy:.1f}m")
            return
        if k == "]":
            self.takeoff_alt_m = min(50.0, self.takeoff_alt_m + 0.5)
            self.get_logger().info(f"takeoff_alt={self.takeoff_alt_m:.1f}m")
            return
        if k == "[":
            self.takeoff_alt_m = max(0.5, self.takeoff_alt_m - 0.5)
            self.get_logger().info(f"takeoff_alt={self.takeoff_alt_m:.1f}m")
            return

        # Manual move cancels takeoff automation
        if k.lower() in ("w", "a", "s", "d", "r", "f", "q", "e"):
            self.takeoff_active = False

        # BODY-relative translation increments
        if k in ("w", "W"):
            dx, dy = self._body_step_to_local(+self.step_body_xy, 0.0)
            self.sp.x += dx
            self.sp.y += dy
        elif k in ("s", "S"):
            dx, dy = self._body_step_to_local(-self.step_body_xy, 0.0)
            self.sp.x += dx
            self.sp.y += dy
        elif k in ("d", "D"):
            dx, dy = self._body_step_to_local(0.0, +self.step_body_xy)  # right
            self.sp.x += dx
            self.sp.y += dy
        elif k in ("a", "A"):
            dx, dy = self._body_step_to_local(0.0, -self.step_body_xy)  # left
            self.sp.x += dx
            self.sp.y += dy

        # Altitude increments (local frame)
        elif k in ("r", "R"):
            self.sp.z -= self.step_z  # UP (more negative)
        elif k in ("f", "F"):
            self.sp.z += self.step_z  # DOWN

        # Yaw setpoint increments
        elif k in ("q", "Q"):
            self.sp.yaw += math.radians(10)
        elif k in ("e", "E"):
            self.sp.yaw -= math.radians(10)
        else:
            return

        # Normalize yaw
        self.sp.yaw = (self.sp.yaw + math.pi) % (2.0 * math.pi) - math.pi

        self.get_logger().info(
            f"SP: x={self.sp.x:.2f} y={self.sp.y:.2f} z={self.sp.z:.2f} alt={-self.sp.z:.2f}m "
            f"yaw_sp={math.degrees(self.sp.yaw):.1f}deg yaw_est={math.degrees(self.yaw_est):.1f}deg ({self.yaw_source})"
        )


def main():
    old = termios.tcgetattr(sys.stdin)
    tty.setcbreak(sys.stdin.fileno())

    rclpy.init()
    node = PX4KeyboardOffboardPositionBody()

    try:
        while rclpy.ok():
            rclpy.spin_once(node, timeout_sec=0.01)
            k = get_key(0.0)
            if k:
                node.handle_key(k)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old)


if __name__ == "__main__":
    main()

