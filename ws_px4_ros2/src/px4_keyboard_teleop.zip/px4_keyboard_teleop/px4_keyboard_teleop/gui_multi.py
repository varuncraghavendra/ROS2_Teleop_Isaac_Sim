#!/usr/bin/env python3
import sys
import math
import argparse
from dataclasses import dataclass
from typing import List, Optional

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.executors import MultiThreadedExecutor

from px4_msgs.msg import OffboardControlMode, TrajectorySetpoint, VehicleCommand
from px4_msgs.msg import VehicleLocalPosition, VehicleOdometry, VehicleAttitude, VehicleStatus

from PyQt5 import QtCore, QtWidgets
from functools import partial


# ---------------- utils ----------------
def quat_to_yaw(qw, qx, qy, qz) -> float:
    siny_cosp = 2.0 * (qw * qz + qx * qy)
    cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
    return math.atan2(siny_cosp, cosy_cosp)


def strip_trailing(s: str) -> str:
    return s[:-1] if s.endswith("/") else s


def ns_for_index(i: int, force_all_namespaced: bool) -> str:
    # If force_all_namespaced=True: /px4_0, /px4_1, ...
    # Else PX4 default: instance0 unnamespaced, others /px4_1...
    if force_all_namespaced:
        return f"/px4_{i}"
    return "" if i == 0 else f"/px4_{i}"


def sysid_for_index(i: int) -> int:
    # PX4 convention: instance i uses MAV_SYS_ID = i+1
    return i + 1


def _nan3():
    n = float("nan")
    return [n, n, n]


def set_traj_position(sp: TrajectorySetpoint, x: float, y: float, z: float):
    # schema-safe: some px4_msgs use x/y/z; others use position[]
    if hasattr(sp, "x") and hasattr(sp, "y") and hasattr(sp, "z"):
        sp.x = float(x); sp.y = float(y); sp.z = float(z)
        return
    if hasattr(sp, "position"):
        pos = list(getattr(sp, "position"))
        if len(pos) < 3:
            pos = [0.0, 0.0, 0.0]
        pos[0], pos[1], pos[2] = float(x), float(y), float(z)
        sp.position = pos
        return
    raise AttributeError("TrajectorySetpoint supports neither x/y/z nor position[]")


def set_traj_mask_unused(sp: TrajectorySetpoint):
    if hasattr(sp, "velocity"):
        sp.velocity = _nan3()
    if hasattr(sp, "acceleration"):
        sp.acceleration = _nan3()
    if hasattr(sp, "jerk"):
        sp.jerk = _nan3()
    if hasattr(sp, "yawspeed"):
        sp.yawspeed = float("nan")


def set_traj_yaw(sp: TrajectorySetpoint, yaw: float):
    if hasattr(sp, "yaw"):
        sp.yaw = float(yaw)


# ---------------- state ----------------
@dataclass
class Pose:
    have: bool = False
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    yaw: float = 0.0
    yaw_have: bool = False
    src: str = "none"


class Mode:
    IDLE = "IDLE"
    OFFBOARD = "OFFBOARD"
    RTL = "RTL"
    DISARMING = "DISARMING"


class DroneCtrl:
    VEHICLE_CMD_DO_SET_MODE = 176
    VEHICLE_CMD_COMPONENT_ARM_DISARM = 400
    VEHICLE_CMD_NAV_RETURN_TO_LAUNCH = 20  # RTL

    PX4_CUSTOM_MAIN_MODE = 1.0
    PX4_OFFBOARD_MODE = 6.0

    def __init__(self, node: Node, idx: int, ns: str, sysid: int):
        self.node = node
        self.idx = idx
        self.ns = strip_trailing(ns)
        self.sysid = int(sysid)

        self.pose = Pose()
        self.arming_state = None
        self.nav_state = None

        self.sp_init = False
        self.sp_x = 0.0
        self.sp_y = 0.0
        self.sp_z = 0.0
        self.sp_yaw = 0.0

        self.mode = Mode.IDLE
        self.stream_count = 0
        self.rtl_ticks_remaining = 0
        self.disarm_ticks_remaining = 0

        self.step_xy = 0.5
        self.step_z = 0.3
        self.step_yaw_deg = 10.0
        self.takeoff_alt_m = 2.5

        # pubs (these are stable names)
        self.pub_offboard = node.create_publisher(
            OffboardControlMode, f"{self.ns}/fmu/in/offboard_control_mode", qos_profile_sensor_data
        )
        self.pub_sp = node.create_publisher(
            TrajectorySetpoint, f"{self.ns}/fmu/in/trajectory_setpoint", qos_profile_sensor_data
        )
        self.pub_cmd = node.create_publisher(
            VehicleCommand, f"{self.ns}/fmu/in/vehicle_command", qos_profile_sensor_data
        )

        # subs:
        # odometry is usually without _v1
        node.create_subscription(
            VehicleOdometry, f"{self.ns}/fmu/out/vehicle_odometry", self._on_odom, qos_profile_sensor_data
        )
        # local position & status often appear as _v1 in XRCE builds, so subscribe to BOTH
        node.create_subscription(
            VehicleLocalPosition, f"{self.ns}/fmu/out/vehicle_local_position", self._on_local, qos_profile_sensor_data
        )
        node.create_subscription(
            VehicleLocalPosition, f"{self.ns}/fmu/out/vehicle_local_position_v1", self._on_local, qos_profile_sensor_data
        )
        node.create_subscription(
            VehicleStatus, f"{self.ns}/fmu/out/vehicle_status", self._on_status, qos_profile_sensor_data
        )
        node.create_subscription(
            VehicleStatus, f"{self.ns}/fmu/out/vehicle_status_v1", self._on_status, qos_profile_sensor_data
        )
        node.create_subscription(
            VehicleAttitude, f"{self.ns}/fmu/out/vehicle_attitude", self._on_att, qos_profile_sensor_data
        )

    def now_us(self) -> int:
        return int(self.node.get_clock().now().nanoseconds / 1000)

    def _on_odom(self, msg: VehicleOdometry):
        self.pose.have = True
        self.pose.x = float(msg.position[0])
        self.pose.y = float(msg.position[1])
        self.pose.z = float(msg.position[2])
        self.pose.src = "odom"
        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.pose.yaw = quat_to_yaw(qw, qx, qy, qz)
        self.pose.yaw_have = True
        if not self.sp_init:
            self.sp_x, self.sp_y, self.sp_z = self.pose.x, self.pose.y, self.pose.z
            self.sp_yaw = self.pose.yaw
            self.sp_init = True

    def _on_local(self, msg: VehicleLocalPosition):
        if self.pose.src == "odom":
            return
        self.pose.have = True
        self.pose.x, self.pose.y, self.pose.z = float(msg.x), float(msg.y), float(msg.z)
        self.pose.src = "local"
        if not self.sp_init:
            self.sp_x, self.sp_y, self.sp_z = self.pose.x, self.pose.y, self.pose.z
            self.sp_init = True

    def _on_att(self, msg: VehicleAttitude):
        if self.pose.yaw_have:
            return
        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.pose.yaw = quat_to_yaw(qw, qx, qy, qz)
        self.pose.yaw_have = True
        if self.sp_init:
            self.sp_yaw = self.pose.yaw

    def _on_status(self, msg: VehicleStatus):
        self.arming_state = int(msg.arming_state)
        self.nav_state = int(msg.nav_state)

    def _send_cmd(self, command: int, p1: float = 0.0, p2: float = 0.0):
        m = VehicleCommand()
        m.timestamp = self.now_us()
        m.param1 = float(p1)
        m.param2 = float(p2)
        m.command = int(command)

        m.target_system = int(self.sysid)
        m.target_component = 1
        m.source_system = 1
        m.source_component = 1
        m.from_external = True
        self.pub_cmd.publish(m)

    def cmd_offboard(self):
        self._send_cmd(self.VEHICLE_CMD_DO_SET_MODE, self.PX4_CUSTOM_MAIN_MODE, self.PX4_OFFBOARD_MODE)

    def cmd_arm(self):
        self._send_cmd(self.VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0, 0.0)

    def cmd_disarm(self):
        self._send_cmd(self.VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0, 0.0)

    def cmd_rtl(self):
        self._send_cmd(self.VEHICLE_CMD_NAV_RETURN_TO_LAUNCH, 0.0, 0.0)

    # -------- UI actions --------
    def init_hold(self) -> bool:
        if not self.pose.have:
            return False
        self.sp_x, self.sp_y, self.sp_z = self.pose.x, self.pose.y, self.pose.z
        self.sp_yaw = self.pose.yaw if self.pose.yaw_have else 0.0
        self.sp_init = True
        return True

    def engage(self) -> bool:
        if not self.pose.have:
            return False
        if not self.sp_init:
            self.init_hold()
        self.mode = Mode.OFFBOARD
        self.stream_count = 0
        return True

    def takeoff(self) -> bool:
        if not self.engage():
            return False
        self.sp_x, self.sp_y = self.pose.x, self.pose.y
        self.sp_z = -float(self.takeoff_alt_m)
        if self.pose.yaw_have:
            self.sp_yaw = self.pose.yaw
        self.sp_init = True
        return True

    def hold(self):
        if self.pose.have:
            self.sp_x, self.sp_y, self.sp_z = self.pose.x, self.pose.y, self.pose.z
            if self.pose.yaw_have:
                self.sp_yaw = self.pose.yaw
            self.sp_init = True
        self.mode = Mode.OFFBOARD
        self.stream_count = 0

    def rtl(self):
        # stop offboard so RTL can take over
        self.mode = Mode.RTL
        self.rtl_ticks_remaining = 40  # ~2s

    def disarm(self):
        self.mode = Mode.DISARMING
        self.disarm_ticks_remaining = 20  # ~1s

    # -------- motion (OFFBOARD only) --------
    def _body_to_local(self, fwd: float, right: float):
        yaw = self.pose.yaw if self.pose.yaw_have else 0.0
        cy, sy = math.cos(yaw), math.sin(yaw)
        dx = fwd * cy - right * sy
        dy = fwd * sy + right * cy
        return dx, dy

    def step_body(self, fwd: float, right: float):
        if self.mode != Mode.OFFBOARD or not self.sp_init:
            return
        dx, dy = self._body_to_local(fwd, right)
        self.sp_x += dx
        self.sp_y += dy

    def step_up(self, up: float):
        if self.mode != Mode.OFFBOARD or not self.sp_init:
            return
        self.sp_z -= float(up)

    def step_yaw(self, deg: float):
        if self.mode != Mode.OFFBOARD or not self.sp_init:
            return
        self.sp_yaw += math.radians(float(deg))
        self.sp_yaw = (self.sp_yaw + math.pi) % (2 * math.pi) - math.pi

    def tick(self):
        if self.mode == Mode.OFFBOARD:
            self.stream_count += 1

            hb = OffboardControlMode()
            hb.timestamp = self.now_us()
            hb.position = True
            hb.velocity = False
            hb.acceleration = False
            hb.attitude = False
            hb.body_rate = False
            self.pub_offboard.publish(hb)

            if self.stream_count >= 30:
                self.cmd_offboard()
                self.cmd_arm()

            sp = TrajectorySetpoint()
            sp.timestamp = self.now_us()
            if self.sp_init:
                set_traj_position(sp, self.sp_x, self.sp_y, self.sp_z)
                set_traj_yaw(sp, self.sp_yaw)
            else:
                n = float("nan")
                set_traj_position(sp, n, n, n)
                set_traj_yaw(sp, n)
            set_traj_mask_unused(sp)
            self.pub_sp.publish(sp)

        elif self.mode == Mode.RTL:
            if self.rtl_ticks_remaining > 0:
                self.cmd_rtl()
                self.rtl_ticks_remaining -= 1
            else:
                self.mode = Mode.IDLE

        elif self.mode == Mode.DISARMING:
            if self.disarm_ticks_remaining > 0:
                self.cmd_disarm()
                self.disarm_ticks_remaining -= 1
            else:
                self.mode = Mode.IDLE

    def status(self) -> str:
        alt = (-self.pose.z) if self.pose.have else None
        yaw_deg = math.degrees(self.pose.yaw) if self.pose.yaw_have else None
        return (
            f"drone_{self.idx} ns={self.ns or '/'} sysid={self.sysid} | mode={self.mode} | "
            f"pose={self.pose.have}({self.pose.src}) "
            + (f"alt={alt:.2f} " if alt is not None else "alt=--- ")
            + (f"yaw={yaw_deg:.1f} " if yaw_deg is not None else "yaw=--- ")
            + f"| arm={self.arming_state} nav={self.nav_state}"
        )


class SwarmGuiNode(Node):
    def __init__(self, ctrls: List[DroneCtrl]):
        super().__init__("px4_swarm_gui")
        self.ctrls = ctrls
        self.timer = self.create_timer(0.05, self._tick_all)

    def _tick_all(self):
        for c in self.ctrls:
            c.tick()

    def engage_all(self):
        for c in self.ctrls:
            c.engage()

    def takeoff_all(self):
        for c in self.ctrls:
            c.takeoff()

    def hold_all(self):
        for c in self.ctrls:
            c.hold()

    def rtl_all(self):
        for c in self.ctrls:
            c.rtl()

    def disarm_all(self):
        for c in self.ctrls:
            c.disarm()


class Window(QtWidgets.QWidget):
    def __init__(self, node: SwarmGuiNode):
        super().__init__()
        self.node = node
        self.active = 0

        self.setWindowTitle("PX4 Swarm GUI (works even if discovery fails)")
        self.setFocusPolicy(QtCore.Qt.StrongFocus)

        root = QtWidgets.QVBoxLayout(self)

        # selector + swarm buttons
        top = QtWidgets.QHBoxLayout()
        root.addLayout(top)

        self.selector = QtWidgets.QComboBox()
        for i, c in enumerate(self.node.ctrls):
            self.selector.addItem(f"Drone {i} (ns={c.ns or '/'} sysid={c.sysid})", i)
        self.selector.currentIndexChanged.connect(self.set_active)
        top.addWidget(QtWidgets.QLabel("Selected drone:"))
        top.addWidget(self.selector)

        b_eng = QtWidgets.QPushButton("Engage ALL")
        b_tko = QtWidgets.QPushButton("Takeoff ALL")
        b_hold = QtWidgets.QPushButton("Hold ALL")
        b_rtl = QtWidgets.QPushButton("Return HOME (RTL) ALL")
        b_dis = QtWidgets.QPushButton("Disarm ALL")
        for b in [b_eng, b_tko, b_hold, b_rtl, b_dis]:
            top.addWidget(b)

        b_eng.clicked.connect(self.node.engage_all)
        b_tko.clicked.connect(self.node.takeoff_all)
        b_hold.clicked.connect(self.node.hold_all)
        b_rtl.clicked.connect(self.node.rtl_all)
        b_dis.clicked.connect(self.node.disarm_all)

        root.addWidget(QtWidgets.QLabel("Keyboard (selected drone): W/A/S/D | R/F | Q/E | TAB next | Shift+TAB prev | 1..9 jump"))

        # per-drone tiles
        self.tiles = []
        self.labels = []

        row = QtWidgets.QHBoxLayout()
        container = QtWidgets.QWidget()
        container.setLayout(row)

        for i, c in enumerate(self.node.ctrls):
            tile = QtWidgets.QFrame()
            tile.setFrameShape(QtWidgets.QFrame.StyledPanel)
            tile.setMinimumWidth(360)
            v = QtWidgets.QVBoxLayout(tile)

            title = QtWidgets.QLabel(f"Drone {i} (ns={c.ns or '/'} sysid={c.sysid})")
            title.setStyleSheet("font-weight:600; font-size:14px;")
            v.addWidget(title)

            lbl = QtWidgets.QLabel("...")
            lbl.setWordWrap(True)
            v.addWidget(lbl)

            btn = QtWidgets.QHBoxLayout()
            v.addLayout(btn)

            bi = QtWidgets.QPushButton("Init")
            be = QtWidgets.QPushButton("Engage")
            bt = QtWidgets.QPushButton("Takeoff")
            bh = QtWidgets.QPushButton("Hold")
            br = QtWidgets.QPushButton("RTL")
            bd = QtWidgets.QPushButton("Disarm")
            for b in [bi, be, bt, bh, br, bd]:
                btn.addWidget(b)

            bi.clicked.connect(partial(c.init_hold))
            be.clicked.connect(partial(c.engage))
            bt.clicked.connect(partial(c.takeoff))
            bh.clicked.connect(partial(c.hold))
            br.clicked.connect(partial(c.rtl))
            bd.clicked.connect(partial(c.disarm))

            row.addWidget(tile)
            self.tiles.append(tile)
            self.labels.append(lbl)

        scroll = QtWidgets.QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(container)
        root.addWidget(scroll)

        self._apply_sel()

        self.ui_timer = QtCore.QTimer()
        self.ui_timer.timeout.connect(self.refresh)
        self.ui_timer.start(100)

        self.resize(1700, 520)

    def set_active(self, idx: int):
        idx = int(idx)
        if idx < 0 or idx >= len(self.node.ctrls):
            return
        self.active = idx
        if self.selector.currentIndex() != idx:
            self.selector.setCurrentIndex(idx)
        self._apply_sel()

    def _apply_sel(self):
        for i, t in enumerate(self.tiles):
            if i == self.active:
                t.setStyleSheet("border:2px solid #2b7cff; border-radius:12px; padding:8px;")
            else:
                t.setStyleSheet("border:1px solid #444444; border-radius:12px; padding:8px;")

    def keyPressEvent(self, e):
        # selection hotkeys
        if e.key() == QtCore.Qt.Key_Tab:
            step = -1 if (e.modifiers() & QtCore.Qt.ShiftModifier) else 1
            self.set_active((self.active + step) % len(self.node.ctrls))
            return
        if QtCore.Qt.Key_1 <= e.key() <= QtCore.Qt.Key_9:
            idx = e.key() - QtCore.Qt.Key_1
            if idx < len(self.node.ctrls):
                self.set_active(idx)
            return

        c = self.node.ctrls[self.active]
        if e.key() == QtCore.Qt.Key_W:
            c.step_body(+c.step_xy, 0.0)
        elif e.key() == QtCore.Qt.Key_S:
            c.step_body(-c.step_xy, 0.0)
        elif e.key() == QtCore.Qt.Key_D:
            c.step_body(0.0, +c.step_xy)
        elif e.key() == QtCore.Qt.Key_A:
            c.step_body(0.0, -c.step_xy)
        elif e.key() == QtCore.Qt.Key_R:
            c.step_up(+c.step_z)
        elif e.key() == QtCore.Qt.Key_F:
            c.step_up(-c.step_z)
        elif e.key() == QtCore.Qt.Key_Q:
            c.step_yaw(+c.step_yaw_deg)
        elif e.key() == QtCore.Qt.Key_E:
            c.step_yaw(-c.step_yaw_deg)

    def refresh(self):
        for i, c in enumerate(self.node.ctrls):
            self.labels[i].setText(c.status())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--num_drones", type=int, default=3)
    ap.add_argument("--force_all_namespaced", action="store_true",
                    help="Use /px4_0,/px4_1,... instead of PX4 default where instance0 is unnamespaced")
    args = ap.parse_args()

    rclpy.init()

    # build fixed list so you can always toggle
    dummy = Node("px4_gui_ctor")
    ctrls: List[DroneCtrl] = []
    for i in range(args.num_drones):
        ns = ns_for_index(i, args.force_all_namespaced)
        ctrls.append(DroneCtrl(dummy, idx=i, ns=ns, sysid=sysid_for_index(i)))

    node = SwarmGuiNode(ctrls)

    executor = MultiThreadedExecutor()
    executor.add_node(dummy)
    executor.add_node(node)

    app = QtWidgets.QApplication(sys.argv)
    win = Window(node)
    win.show()

    spin_timer = QtCore.QTimer()
    spin_timer.timeout.connect(lambda: executor.spin_once(timeout_sec=0.0))
    spin_timer.start(5)

    rc = app.exec_()

    executor.remove_node(node)
    executor.remove_node(dummy)
    node.destroy_node()
    dummy.destroy_node()
    rclpy.shutdown()
    sys.exit(rc)


if __name__ == "__main__":
    main()

