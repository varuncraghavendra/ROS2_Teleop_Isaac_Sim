#!/usr/bin/env python3
import sys
import math
from dataclasses import dataclass

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data

from px4_msgs.msg import OffboardControlMode, TrajectorySetpoint, VehicleCommand
from px4_msgs.msg import VehicleLocalPosition, VehicleOdometry, VehicleAttitude, VehicleStatus

from PyQt5 import QtCore, QtGui, QtWidgets


@dataclass
class Setpoint:
    x: float = 0.0   # local NED
    y: float = 0.0
    z: float = 0.0   # down (up is negative)
    yaw: float = 0.0 # rad


def quat_to_yaw(qw, qx, qy, qz) -> float:
    """Quaternion -> yaw (rad)."""
    siny_cosp = 2.0 * (qw * qz + qx * qy)
    cosy_cosp = 1.0 - 2.0 * (qy * qy + qz * qz)
    return math.atan2(siny_cosp, cosy_cosp)


class PX4OffboardPositionController(Node):
    """
    Core OFFBOARD position controller:
      - Streams OffboardControlMode + TrajectorySetpoint at 20 Hz
      - Body-relative XY stepping (WASD in GUI)
      - Buttons: init, arm, disarm, offboard, takeoff, hold, return-to-dock (RTH/RTL)
    """

    VEHICLE_CMD_DO_SET_MODE = 176
    VEHICLE_CMD_COMPONENT_ARM_DISARM = 400
    VEHICLE_CMD_NAV_RETURN_TO_LAUNCH = 20  # RTL / RTH
    # NOTE: "Return to Dock" here is mapped to PX4 RTL. If you have a dock mission/precision-landing flow,
    #       we can wire it to DO_REPOSITION / MISSION_START / custom docking waypoint.

    PX4_CUSTOM_MAIN_MODE = 1.0
    PX4_OFFBOARD_MODE = 6.0

    def __init__(self):
        super().__init__("px4_offboard_gui_controller")

        # Publishers
        self.pub_offboard = self.create_publisher(
            OffboardControlMode, "/fmu/in/offboard_control_mode", qos_profile_sensor_data
        )
        self.pub_sp = self.create_publisher(
            TrajectorySetpoint, "/fmu/in/trajectory_setpoint", qos_profile_sensor_data
        )
        self.pub_cmd = self.create_publisher(
            VehicleCommand, "/fmu/in/vehicle_command", qos_profile_sensor_data
        )

        # Subscriptions
        self.sub_local = self.create_subscription(
            VehicleLocalPosition, "/fmu/out/vehicle_local_position", self._on_local, qos_profile_sensor_data
        )
        self.sub_odom = self.create_subscription(
            VehicleOdometry, "/fmu/out/vehicle_odometry", self._on_odom, qos_profile_sensor_data
        )
        self.sub_att = self.create_subscription(
            VehicleAttitude, "/fmu/out/vehicle_attitude", self._on_att, qos_profile_sensor_data
        )
        self.sub_status = self.create_subscription(
            VehicleStatus, "/fmu/out/vehicle_status", self._on_status, qos_profile_sensor_data
        )

        # 20 Hz stream timer
        self.timer = self.create_timer(0.05, self._tick)
        self.stream_count = 0

        # Estimator state
        self.have_pose = False
        self.pose_source = "none"
        self.x = self.y = self.z = 0.0

        self.have_yaw = False
        self.yaw_est = 0.0
        self.yaw_source = "none"

        self.have_status = False
        self.arming_state = None
        self.nav_state = None

        # Setpoint
        self.sp = Setpoint()

        # Tunables (GUI)
        self.step_xy = 0.5
        self.step_z = 0.3
        self.step_yaw_deg = 10.0
        self.takeoff_alt_m = 2.5

        # Safety
        self.alt_ceiling_m = 30.0
        self.alt_floor_m = 0.1

        # Request flags (avoid spamming)
        self._arm_requested = False
        self._offboard_requested = False

        # Takeoff state
        self.takeoff_active = False

    def now_us(self) -> int:
        return int(self.get_clock().now().nanoseconds / 1000)

    # ----- subscriptions -----
    def _on_local(self, msg: VehicleLocalPosition):
        self.x, self.y, self.z = float(msg.x), float(msg.y), float(msg.z)
        self.have_pose = True
        self.pose_source = "vehicle_local_position"

    def _on_odom(self, msg: VehicleOdometry):
        if self.pose_source != "vehicle_local_position":
            self.x, self.y, self.z = float(msg.position[0]), float(msg.position[1]), float(msg.position[2])
            self.have_pose = True
            self.pose_source = "vehicle_odometry"

        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.yaw_est = quat_to_yaw(qw, qx, qy, qz)
        self.have_yaw = True
        self.yaw_source = "vehicle_odometry"

    def _on_att(self, msg: VehicleAttitude):
        if self.yaw_source == "vehicle_odometry":
            return
        qw, qx, qy, qz = float(msg.q[0]), float(msg.q[1]), float(msg.q[2]), float(msg.q[3])
        self.yaw_est = quat_to_yaw(qw, qx, qy, qz)
        self.have_yaw = True
        self.yaw_source = "vehicle_attitude"

    def _on_status(self, msg: VehicleStatus):
        self.have_status = True
        self.arming_state = int(msg.arming_state)
        self.nav_state = int(msg.nav_state)

    # ----- command helpers -----
    def _send_cmd(self, command: int, p1: float = 0.0, p2: float = 0.0):
        m = VehicleCommand()
        m.timestamp = self.now_us()
        m.param1 = float(p1)
        m.param2 = float(p2)
        m.command = int(command)
        m.target_system = 1
        m.target_component = 1
        m.source_system = 1
        m.source_component = 1
        m.from_external = True
        self.pub_cmd.publish(m)

    def request_arm(self):
        if not self._arm_requested:
            self._send_cmd(self.VEHICLE_CMD_COMPONENT_ARM_DISARM, 1.0, 0.0)
            self._arm_requested = True

    def disarm(self):
        self._send_cmd(self.VEHICLE_CMD_COMPONENT_ARM_DISARM, 0.0, 0.0)
        self._arm_requested = False

    def request_offboard(self):
        if not self._offboard_requested:
            self._send_cmd(self.VEHICLE_CMD_DO_SET_MODE, self.PX4_CUSTOM_MAIN_MODE, self.PX4_OFFBOARD_MODE)
            self._offboard_requested = True

    def return_to_dock(self):
        # Map "Return to Dock" -> RTL / RTH in PX4
        self.takeoff_active = False
        self._send_cmd(self.VEHICLE_CMD_NAV_RETURN_TO_LAUNCH, 0.0, 0.0)
        # allow re-arming/offboard later if operator wants to resume
        self._offboard_requested = False

    # ----- setpoint helpers -----
    def init_setpoint_to_current(self):
        if not self.have_pose:
            return False
        self.sp.x, self.sp.y, self.sp.z = self.x, self.y, self.z
        if self.have_yaw:
            self.sp.yaw = self.yaw_est
        self.takeoff_active = False
        return True

    def hold(self):
        if self.have_pose:
            self.sp.x, self.sp.y, self.sp.z = self.x, self.y, self.z
        self.takeoff_active = False

    def start_takeoff(self):
        if not self.have_pose:
            return False
        self.sp.x, self.sp.y = self.x, self.y
        self.sp.z = -self.takeoff_alt_m  # up => negative z
        if self.have_yaw:
            self.sp.yaw = self.yaw_est
        self.takeoff_active = True
        return True

    def _body_to_local_dxdy(self, forward_m: float, right_m: float):
        yaw = self.yaw_est if self.have_yaw else 0.0
        cy = math.cos(yaw)
        sy = math.sin(yaw)
        dx = forward_m * cy - right_m * sy
        dy = forward_m * sy + right_m * cy
        return dx, dy

    def step_body(self, forward_m: float, right_m: float):
        self.takeoff_active = False
        dx, dy = self._body_to_local_dxdy(forward_m, right_m)
        self.sp.x += dx
        self.sp.y += dy

    def step_up(self, up_m: float):
        self.takeoff_active = False
        self.sp.z -= up_m  # up => z more negative

    def step_yaw(self, deg: float):
        self.takeoff_active = False
        self.sp.yaw += math.radians(deg)
        self.sp.yaw = (self.sp.yaw + math.pi) % (2.0 * math.pi) - math.pi

    def _clamp_alt(self):
        target_alt = -self.sp.z
        if target_alt > self.alt_ceiling_m:
            self.sp.z = -self.alt_ceiling_m
        if target_alt < self.alt_floor_m:
            self.sp.z = -self.alt_floor_m

    # ----- streaming -----
    def _tick(self):
        self.stream_count += 1

        hb = OffboardControlMode()
        hb.timestamp = self.now_us()
        hb.position = True
        hb.velocity = False
        hb.acceleration = False
        hb.attitude = False
        hb.body_rate = False
        self.pub_offboard.publish(hb)

        # During takeoff: after ~1s of streaming, request arm+offboard once
        if self.takeoff_active and self.stream_count > 20:
            self.request_arm()
            self.request_offboard()

        self._clamp_alt()
        sp = TrajectorySetpoint()
        sp.timestamp = self.now_us()
        sp.position = [float(self.sp.x), float(self.sp.y), float(self.sp.z)]
        sp.yaw = float(self.sp.yaw)
        self.pub_sp.publish(sp)

    # ----- telemetry for UI -----
    def telemetry(self):
        alt = (-self.z) if self.have_pose else None
        yaw_deg = math.degrees(self.yaw_est) if self.have_yaw else None

        return {
            "have_pose": self.have_pose,
            "pose_source": self.pose_source,
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "alt": alt,
            "have_yaw": self.have_yaw,
            "yaw_deg": yaw_deg,
            "yaw_source": self.yaw_source,
            "arming_state": self.arming_state,
            "nav_state": self.nav_state,
            "sp_x": self.sp.x,
            "sp_y": self.sp.y,
            "sp_z": self.sp.z,
            "sp_alt": -self.sp.z,
            "sp_yaw_deg": math.degrees(self.sp.yaw),
        }


# ---------- UI helpers ----------
def pill_color(ok: bool) -> str:
    return "#2ecc71" if ok else "#e74c3c"


def state_badge(text: str, color: str) -> str:
    return f"""
    <span style="
        padding:3px 10px;
        border-radius:999px;
        background:{color};
        color:#0b0f14;
        font-weight:700;
        font-size:12px;">
        {text}
    </span>
    """


class Card(QtWidgets.QFrame):
    def __init__(self, title: str, subtitle: str = ""):
        super().__init__()
        self.setObjectName("Card")
        self.v = QtWidgets.QVBoxLayout(self)
        self.v.setContentsMargins(16, 14, 16, 14)
        self.v.setSpacing(8)

        self.title = QtWidgets.QLabel(title)
        self.title.setObjectName("CardTitle")
        self.v.addWidget(self.title)

        if subtitle:
            self.subtitle = QtWidgets.QLabel(subtitle)
            self.subtitle.setObjectName("CardSubTitle")
            self.subtitle.setWordWrap(True)
            self.v.addWidget(self.subtitle)


class GUI(QtWidgets.QWidget):
    def __init__(self, ctrl: PX4OffboardPositionController):
        super().__init__()
        self.ctrl = ctrl
        self.setWindowTitle("Warehouse Scan Ops Console — PX4 Offboard (Isaac + ROS 2)")
        self.setMinimumSize(980, 560)

        self._apply_theme()

        # ===== Header =====
        self.header = QtWidgets.QFrame()
        self.header.setObjectName("Header")
        h = QtWidgets.QHBoxLayout(self.header)
        h.setContentsMargins(18, 14, 18, 14)
        h.setSpacing(14)

        self.h_title = QtWidgets.QLabel("Warehouse Scan Ops Console")
        self.h_title.setObjectName("HeaderTitle")

        self.h_sub = QtWidgets.QLabel("PX4 OFFBOARD • Telemetry + Manual NED Setpoints")
        self.h_sub.setObjectName("HeaderSub")

        title_col = QtWidgets.QVBoxLayout()
        title_col.setSpacing(2)
        title_col.addWidget(self.h_title)
        title_col.addWidget(self.h_sub)

        self.badge_pose = QtWidgets.QLabel()
        self.badge_pose.setTextFormat(QtCore.Qt.RichText)
        self.badge_arm = QtWidgets.QLabel()
        self.badge_arm.setTextFormat(QtCore.Qt.RichText)
        self.badge_nav = QtWidgets.QLabel()
        self.badge_nav.setTextFormat(QtCore.Qt.RichText)

        badge_row = QtWidgets.QHBoxLayout()
        badge_row.setSpacing(10)
        badge_row.addWidget(self.badge_pose)
        badge_row.addWidget(self.badge_arm)
        badge_row.addWidget(self.badge_nav)
        badge_row.addStretch(1)

        h.addLayout(title_col)
        h.addStretch(1)
        h.addLayout(badge_row)

        # ===== Controls (left) =====
        left = QtWidgets.QFrame()
        left.setObjectName("LeftPanel")
        left_layout = QtWidgets.QVBoxLayout(left)
        left_layout.setContentsMargins(14, 14, 14, 14)
        left_layout.setSpacing(12)

        # Action buttons
        self.card_actions = Card("Actions", "Operator controls for arming/offboard/flight phases.")
        left_layout.addWidget(self.card_actions)

        actions_grid = QtWidgets.QGridLayout()
        actions_grid.setHorizontalSpacing(10)
        actions_grid.setVerticalSpacing(10)
        self.card_actions.v.addLayout(actions_grid)

        self.btn_init = QtWidgets.QPushButton("Init SP = Current")
        self.btn_arm = QtWidgets.QPushButton("ARM")
        self.btn_disarm = QtWidgets.QPushButton("DISARM")
        self.btn_offboard = QtWidgets.QPushButton("OFFBOARD")
        self.btn_takeoff = QtWidgets.QPushButton("TAKEOFF")
        self.btn_hold = QtWidgets.QPushButton("HOLD")
        self.btn_rth = QtWidgets.QPushButton("Return to Dock (RTH)")

        self.btn_disarm.setProperty("danger", True)
        self.btn_rth.setProperty("warn", True)

        actions_grid.addWidget(self.btn_init, 0, 0, 1, 2)
        actions_grid.addWidget(self.btn_arm, 1, 0)
        actions_grid.addWidget(self.btn_disarm, 1, 1)
        actions_grid.addWidget(self.btn_offboard, 2, 0)
        actions_grid.addWidget(self.btn_takeoff, 2, 1)
        actions_grid.addWidget(self.btn_hold, 3, 0)
        actions_grid.addWidget(self.btn_rth, 3, 1)

        # Parameters
        self.card_params = Card("Setpoint Parameters", "Step sizes and takeoff height.")
        left_layout.addWidget(self.card_params)

        form = QtWidgets.QFormLayout()
        form.setLabelAlignment(QtCore.Qt.AlignLeft)
        form.setFormAlignment(QtCore.Qt.AlignTop)
        form.setHorizontalSpacing(14)
        form.setVerticalSpacing(10)
        self.card_params.v.addLayout(form)

        self.step_xy = QtWidgets.QDoubleSpinBox()
        self.step_xy.setRange(0.1, 5.0)
        self.step_xy.setSingleStep(0.1)
        self.step_xy.setValue(self.ctrl.step_xy)

        self.step_z = QtWidgets.QDoubleSpinBox()
        self.step_z.setRange(0.05, 3.0)
        self.step_z.setSingleStep(0.05)
        self.step_z.setValue(self.ctrl.step_z)

        self.takeoff_alt = QtWidgets.QDoubleSpinBox()
        self.takeoff_alt.setRange(0.5, 50.0)
        self.takeoff_alt.setSingleStep(0.5)
        self.takeoff_alt.setValue(self.ctrl.takeoff_alt_m)

        self.yaw_step = QtWidgets.QDoubleSpinBox()
        self.yaw_step.setRange(1.0, 90.0)
        self.yaw_step.setSingleStep(1.0)
        self.yaw_step.setValue(self.ctrl.step_yaw_deg)

        form.addRow("Step XY (m)", self.step_xy)
        form.addRow("Step Z (m)", self.step_z)
        form.addRow("Yaw step (deg)", self.yaw_step)
        form.addRow("Takeoff Alt (m)", self.takeoff_alt)

        # Keyboard cheat sheet
        self.card_keys = Card("Keyboard", "Click window to focus. Manual body-frame moves.")
        left_layout.addWidget(self.card_keys)

        keys = QtWidgets.QLabel(
            "W/A/S/D: move (body)\n"
            "R/F: up/down\n"
            "Q/E: yaw\n"
            "Space: arm\n"
            "O: offboard\n"
            "T: takeoff\n"
            "H: hold\n"
            "B: Return to Dock (RTH)\n"
            "Shift + D: disarm"
        )
        keys.setObjectName("Mono")
        self.card_keys.v.addWidget(keys)

        left_layout.addStretch(1)

        # ===== Telemetry (right) =====
        right = QtWidgets.QFrame()
        right.setObjectName("RightPanel")
        right_layout = QtWidgets.QVBoxLayout(right)
        right_layout.setContentsMargins(14, 14, 14, 14)
        right_layout.setSpacing(12)

        self.card_live = Card("Live Telemetry", "Estimator + nav state (raw).")
        right_layout.addWidget(self.card_live)

        self.lbl_live = QtWidgets.QLabel("")
        self.lbl_live.setObjectName("Telemetry")
        self.lbl_live.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.card_live.v.addWidget(self.lbl_live)

        self.card_sp = Card("Active Setpoint", "Target being streamed to PX4 at 20 Hz.")
        right_layout.addWidget(self.card_sp)

        self.lbl_sp = QtWidgets.QLabel("")
        self.lbl_sp.setObjectName("Telemetry")
        self.lbl_sp.setTextInteractionFlags(QtCore.Qt.TextSelectableByMouse)
        self.card_sp.v.addWidget(self.lbl_sp)

        # A “scan status” style card (visual vibe)
        self.card_ops = Card("Ops Status", "Warehouse scan run monitoring (UI placeholder).")
        right_layout.addWidget(self.card_ops)

        ops_grid = QtWidgets.QGridLayout()
        ops_grid.setHorizontalSpacing(12)
        ops_grid.setVerticalSpacing(10)
        self.card_ops.v.addLayout(ops_grid)

        self.ops_line1 = QtWidgets.QLabel("Mission: Manual Assist")
        self.ops_line2 = QtWidgets.QLabel("Zone: Aisle-12 • Rack-04")
        self.ops_line3 = QtWidgets.QLabel("Stream: 20 Hz setpoints")
        for w in (self.ops_line1, self.ops_line2, self.ops_line3):
            w.setObjectName("OpsLine")

        ops_grid.addWidget(self.ops_line1, 0, 0, 1, 2)
        ops_grid.addWidget(self.ops_line2, 1, 0, 1, 2)
        ops_grid.addWidget(self.ops_line3, 2, 0, 1, 2)

        right_layout.addStretch(1)

        # ===== Root layout =====
        root = QtWidgets.QVBoxLayout(self)
        root.setContentsMargins(14, 14, 14, 14)
        root.setSpacing(12)
        root.addWidget(self.header)

        body = QtWidgets.QHBoxLayout()
        body.setSpacing(12)
        body.addWidget(left, 1)
        body.addWidget(right, 2)
        root.addLayout(body)

        # Wire buttons
        self.btn_init.clicked.connect(self.on_init)
        self.btn_arm.clicked.connect(self.on_arm)
        self.btn_disarm.clicked.connect(self.on_disarm)
        self.btn_offboard.clicked.connect(self.on_offboard)
        self.btn_takeoff.clicked.connect(self.on_takeoff)
        self.btn_hold.clicked.connect(self.on_hold)
        self.btn_rth.clicked.connect(self.on_rth)

        # Wire controls
        self.step_xy.valueChanged.connect(self.on_params_changed)
        self.step_z.valueChanged.connect(self.on_params_changed)
        self.takeoff_alt.valueChanged.connect(self.on_params_changed)
        self.yaw_step.valueChanged.connect(self.on_params_changed)

        # UI refresh timer
        self.ui_timer = QtCore.QTimer()
        self.ui_timer.timeout.connect(self.refresh)
        self.ui_timer.start(100)  # 10 Hz

        self.setFocusPolicy(QtCore.Qt.StrongFocus)

    def _apply_theme(self):
        # Dark WMS-style dashboard theme (no external assets)
        self.setStyleSheet("""
            QWidget {
                background: #0b0f14;
                color: #e7eef7;
                font-family: Inter, Segoe UI, Roboto, Arial;
                font-size: 13px;
            }
            #Header {
                background: #0f1722;
                border: 1px solid #1d2a3a;
                border-radius: 16px;
            }
            #HeaderTitle {
                font-size: 18px;
                font-weight: 800;
                letter-spacing: 0.2px;
            }
            #HeaderSub {
                color: #9bb0c7;
                font-size: 12px;
            }

            #LeftPanel, #RightPanel {
                background: transparent;
            }

            QFrame#Card {
                background: #0f1722;
                border: 1px solid #1d2a3a;
                border-radius: 16px;
            }
            QLabel#CardTitle {
                font-size: 13px;
                font-weight: 800;
            }
            QLabel#CardSubTitle {
                color: #9bb0c7;
                font-size: 12px;
            }

            QPushButton {
                background: #121e2d;
                border: 1px solid #22324a;
                border-radius: 12px;
                padding: 10px 12px;
                font-weight: 700;
            }
            QPushButton:hover {
                background: #152439;
                border-color: #2a3f5e;
            }
            QPushButton:pressed {
                background: #0f1a28;
            }
            QPushButton[danger="true"] {
                background: #2a1114;
                border-color: #5a1e26;
            }
            QPushButton[danger="true"]:hover {
                background: #35161a;
                border-color: #7a2a35;
            }
            QPushButton[warn="true"] {
                background: #2a1c11;
                border-color: #5a3a1e;
            }
            QPushButton[warn="true"]:hover {
                background: #352313;
                border-color: #7a4d2a;
            }

            QDoubleSpinBox {
                background: #0b1220;
                border: 1px solid #22324a;
                border-radius: 10px;
                padding: 6px 8px;
                min-height: 28px;
            }
            QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {
                width: 16px;
            }
            QLabel#Telemetry {
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New";
                background: #0b1220;
                border: 1px solid #22324a;
                border-radius: 12px;
                padding: 10px;
                line-height: 1.35;
            }
            QLabel#Mono {
                font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New";
                color: #cfe2ff;
            }
            QLabel#OpsLine {
                color: #cfe2ff;
                font-weight: 700;
            }
        """)

    def on_params_changed(self):
        self.ctrl.step_xy = float(self.step_xy.value())
        self.ctrl.step_z = float(self.step_z.value())
        self.ctrl.takeoff_alt_m = float(self.takeoff_alt.value())
        self.ctrl.step_yaw_deg = float(self.yaw_step.value())

    def on_init(self):
        ok = self.ctrl.init_setpoint_to_current()
        if not ok:
            QtWidgets.QMessageBox.warning(self, "No pose", "No estimator pose yet (/fmu/out/*).")

    def on_arm(self):
        self.ctrl.request_arm()

    def on_disarm(self):
        self.ctrl.disarm()

    def on_offboard(self):
        if not self.ctrl.have_pose:
            QtWidgets.QMessageBox.warning(self, "No pose", "No estimator pose yet (/fmu/out/*).")
            return
        self.ctrl.request_offboard()

    def on_takeoff(self):
        ok = self.ctrl.start_takeoff()
        if not ok:
            QtWidgets.QMessageBox.warning(self, "No pose", "No estimator pose yet (/fmu/out/*).")

    def on_hold(self):
        self.ctrl.hold()

    def on_rth(self):
        # “Return to Dock (RTH)” -> PX4 RTL command
        self.ctrl.return_to_dock()

    def keyPressEvent(self, e):
        k = e.key()
        mods = e.modifiers()

        sxy = self.ctrl.step_xy
        sz = self.ctrl.step_z

        # Shift+D = DISARM (so D can still be "right" without shift)
        if (mods & QtCore.Qt.ShiftModifier) and k == QtCore.Qt.Key_D:
            self.ctrl.disarm()
            return

        if k == QtCore.Qt.Key_W:
            self.ctrl.step_body(+sxy, 0.0)
        elif k == QtCore.Qt.Key_S:
            self.ctrl.step_body(-sxy, 0.0)
        elif k == QtCore.Qt.Key_D:
            self.ctrl.step_body(0.0, +sxy)
        elif k == QtCore.Qt.Key_A:
            self.ctrl.step_body(0.0, -sxy)
        elif k == QtCore.Qt.Key_R:
            self.ctrl.step_up(+sz)
        elif k == QtCore.Qt.Key_F:
            self.ctrl.step_up(-sz)
        elif k == QtCore.Qt.Key_Q:
            self.ctrl.step_yaw(+self.ctrl.step_yaw_deg)
        elif k == QtCore.Qt.Key_E:
            self.ctrl.step_yaw(-self.ctrl.step_yaw_deg)
        elif k == QtCore.Qt.Key_Space:
            self.ctrl.request_arm()
        elif k == QtCore.Qt.Key_O:
            self.ctrl.request_offboard()
        elif k == QtCore.Qt.Key_T:
            self.ctrl.start_takeoff()
        elif k == QtCore.Qt.Key_H:
            self.ctrl.hold()
        elif k == QtCore.Qt.Key_B:
            self.ctrl.return_to_dock()

    def refresh(self):
        t = self.ctrl.telemetry()

        # Header badges
        pose_ok = bool(t["have_pose"])
        self.badge_pose.setText(state_badge("POSE OK" if pose_ok else "NO POSE", pill_color(pose_ok)))

        arm_txt = f"ARM={t['arming_state']}" if t["arming_state"] is not None else "ARM=---"
        self.badge_arm.setText(state_badge(arm_txt, "#00d1ff" if t["arming_state"] else "#334155"))

        nav_txt = f"NAV={t['nav_state']}" if t["nav_state"] is not None else "NAV=---"
        self.badge_nav.setText(state_badge(nav_txt, "#a78bfa" if t["nav_state"] is not None else "#334155"))

        # Live telemetry
        alt_str = ("%.2f" % t["alt"]) if t["alt"] is not None else "---"
        yaw_str = ("%.1f" % t["yaw_deg"]) if t["yaw_deg"] is not None else "---"

        self.lbl_live.setText(
            "LOCAL POSE (NED)\n"
            f"  x={t['x']:+.2f}  y={t['y']:+.2f}  z={t['z']:+.2f}   alt={alt_str} m\n"
            f"  source={t['pose_source']}\n\n"
            "ATTITUDE\n"
            f"  yaw={yaw_str}°   source={t['yaw_source']}\n\n"
            "STATE\n"
            f"  arming_state={t['arming_state']}   nav_state={t['nav_state']}"
        )

        self.lbl_sp.setText(
            "STREAMED SETPOINT\n"
            f"  x={t['sp_x']:+.2f}  y={t['sp_y']:+.2f}  z={t['sp_z']:+.2f}   alt={t['sp_alt']:.2f} m\n"
            f"  yaw_sp={t['sp_yaw_deg']:+.1f}°\n\n"
            f"STEP SIZES\n"
            f"  xy={self.ctrl.step_xy:.2f} m   z={self.ctrl.step_z:.2f} m   yaw_step={self.ctrl.step_yaw_deg:.1f}°"
        )


def main():
    rclpy.init()

    ctrl = PX4OffboardPositionController()

    app = QtWidgets.QApplication(sys.argv)
    app.setApplicationName("Warehouse Scan Ops Console")
    gui = GUI(ctrl)
    gui.show()

    # Spin ROS inside Qt
    spin_timer = QtCore.QTimer()
    spin_timer.timeout.connect(lambda: rclpy.spin_once(ctrl, timeout_sec=0.0))
    spin_timer.start(10)

    rc = app.exec_()

    ctrl.destroy_node()
    rclpy.shutdown()
    sys.exit(rc)


if __name__ == "__main__":
    main()

