from setuptools import find_packages, setup

package_name = "px4_keyboard_teleop"

setup(
    name=package_name,
    version="0.1.0",
    packages=find_packages(exclude=["test"]),
    data_files=[
        ("share/ament_index/resource_index/packages", ["resource/" + package_name]),
        ("share/" + package_name, ["package.xml"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="varun",
    maintainer_email="varun@todo.todo",
    description="PX4 Offboard (DDS) keyboard + GUI teleop for Isaac Sim / SITL.",
    license="Apache-2.0",
    entry_points={
        "console_scripts": [
            # Existing nodes
            "teleop = px4_keyboard_teleop.teleop:main",
            "gui = px4_keyboard_teleop.gui:main",

            # ✅ NEW multi-drone GUI
            "gui_multi = px4_keyboard_teleop.gui_multi:main",

            # (Optional future nodes)
            # "planner = px4_keyboard_teleop.planner:main",
            # "logger = px4_keyboard_teleop.logger:main",
        ],
    },
)

